import random

def generate_question():
    num1 = random.randint(1, 10)
    num2 = random.randint(1, 10)
    operation = random.choice(['+', '-', '*'])

    if operation == '+':
        answer = num1 + num2
    elif operation == '-':
        answer = num1 - num2
    else:
        answer = num1 * num2

    return f"What is {num1} {operation} {num2}?", answer

def math_quiz():
    score = 0
    total_questions = 5

    print("🧮 Welcome to the Math Quiz!")
    print(f"Answer {total_questions} questions to the best of your ability.\n")

    for i in range(total_questions):
        question, answer = generate_question()
        print(f"Question {i + 1}: {question}")
        
        try:
            user_answer = int(input("Your answer: "))
            if user_answer == answer:
                print("✅ Correct!\n")
                score += 1
            else:
                print(f"❌ Wrong! The correct answer was {answer}.\n")
        except ValueError:
            print("⚠️ Please enter a valid number.\n")

    print(f"🎉 Quiz finished! You got {score} out of {total_questions} correct.")

if __name__ == "__main__":
    math_quiz()
